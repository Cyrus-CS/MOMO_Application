//Ces deux lignes permettent d'éviter des inclusions infinies

#ifndef FUNCION_MOMO
#define FUNCION_MOMO

// déclarations des prototypes de fonctions
void sendMoney();
void receiveMoney();
void ConsulteSolde();
void editPin();
void createCompte();


// nom de la variable  fichier initialisée
FILE *filename = NULL;
FILE *fileTransferts = NULL;

// déclaration des variables globales;
long pin = 0;
char lastName[100], firstName[100], numberPhone[100];
int age = 0;
float solde = 0;

//La personne(interlocuteur)  qui peut recevoir et envoyer l'argent
typedef struct {
    char numero[20];
    char nom[100];
    char prenom[100];
    int age;
    float solde;
    long pin;
} Personne;

void sendMoney() {
    long pinEmetteur, pinRecepteur;
    char numberPhoneRecepteur[20];
    float montant;
    int trouveEmetteur = 0, trouveRecepteur = 0;
    FILE *filename, *tempFile;
    char lastName[100], firstName[100], numberPhone[20];
    float solde;
    int age;
    long pin;

    printf("============= TRANSFERT D'ARGENT =============\n");
    printf("[+] Entrez votre code pin: ");
    scanf("%ld", &pinEmetteur);

    printf("[+] Entrez le numéro de telephone du récepteur: ");
    scanf("%99s", numberPhoneRecepteur);

    printf("[+] Entrez le montant a transferer: ");
    scanf("%f", &montant);

    filename = fopen("Compte.txt", "r");
    tempFile = fopen("TempCompte.txt", "w");

    if (filename == NULL || tempFile == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        exit(1);
    }

    while (fscanf(filename, "%ld %99s %99s %99s %d %f\n", &pin, lastName, firstName, numberPhone, &age, &solde) == 6) {
        if (pinEmetteur == pin && solde >= montant) {
            solde -= montant;
            trouveEmetteur = 1;
        }
        if (strcmp(numberPhoneRecepteur, numberPhone) == 0) {
            trouveRecepteur = 1;
            pinRecepteur = pin; // Sauvegarde du pin du récepteur pour la mise à jour ultérieure
        }
        fprintf(tempFile, "%ld %s %s %s %d %.2f\n", pin, lastName, firstName, numberPhone, age, solde);
    }

    if (!trouveEmetteur) {
        printf("Aucun compte emetteur trouve ou solde insuffisant.\n");
    } else if (!trouveRecepteur) {
        printf("Le numero de telephone du recepteur n'existe pas.\n");
    } else {
        // Mise à jour du solde du récepteur
        rewind(filename);
        rewind(tempFile);
        while (fscanf(tempFile, "%ld %99s %99s %99s %d %f\n", &pin, lastName, firstName, numberPhone, &age, &solde) == 6) {
            if (pinRecepteur == pin) {
                solde += montant;
            }
            fprintf(tempFile, "%ld %s %s %s %d %.2f\n", pin, lastName, firstName, numberPhone, age, solde);
        }
        printf("Transfert de %.2f reussi du compte %ld vers le numero %s.\n", montant, pinEmetteur, numberPhoneRecepteur);
    }

    fclose(filename);
    fclose(tempFile);

    // Remplacer le fichier original par le fichier temporaire
    remove("Compte.txt");
    rename("TempCompte.txt", "Compte.txt");
}


// La fonction d'recevoir d'argent qui transfera l'argent d'un compte b(recevoirCompte.txt) vers un autre compte a(envoyer.txt)
void receiveMoney() {
    long pinRecepteur;
    char numberPhoneEmetteur[20];
    float montant;
    int trouveRecepteur = 0, trouveEmetteur = 0;
    FILE *filename, *tempFile;
    char lastName[100], firstName[100], numberPhone[20];
    float solde;
    int age;
    long pin;

    printf("============= RECEPTION D'ARGENT =============\n");
    printf("[+] Entrez votre code pin: ");
    scanf("%ld", &pinRecepteur);

    printf("[+] Entrez le numéro de telelphone de l'emetteur: ");
    scanf("%99s", numberPhoneEmetteur);

    printf("[+] Entrez le montant que vous attendez de recevoir: ");
    scanf("%f", &montant);

    filename = fopen("Compte.txt", "r+");
    tempFile = fopen("TempCompte.txt", "w");

    if (filename == NULL || tempFile == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        exit(1);
    }

    while (fscanf(filename, "%ld %99s %99s %99s %d %f\n", &pin, lastName, firstName, numberPhone, &age, &solde) == 6) {
        if (pinRecepteur == pin) {
            solde += montant;
            trouveRecepteur = 1;
        }
        if (strcmp(numberPhoneEmetteur, numberPhone) == 0) {
            solde -= montant;
            trouveEmetteur = 1;
        }
        fprintf(tempFile, "%ld %s %s %s %d %.2f\n", pin, lastName, firstName, numberPhone, age, solde);
    }

    if (!trouveRecepteur) {
        printf("Aucun compte récepteur trouve avec ce code PIN.\n");
    } else if (!trouveEmetteur) {
        printf("Le numero de téléphone de l'emetteur n'existe pas.\n");
    } else {
        printf("Vous avez recu %.2f du numéro %s.\n", montant, numberPhoneEmetteur);
    }

    fclose(filename);
    fclose(tempFile);

    // Remplacer le fichier original par le fichier temporaire
    remove("Compte.txt");
    rename("TempCompte.txt", "Compte.txt");
}



//fonction pour la consultation du solde de l'utilisateur
void ConsulteSolde() {
    long pinRech;
    FILE *filename;
    char lastName[100], firstName[100], numberPhone[20];
    float solde;
    int age;
    long pin;
    int trouve = 0;

    printf("============= CONSULTATION DU SOLDE =============\n");
    printf("[+] Entrez votre code pin pour consulter votre solde: ");
    scanf("%ld", &pinRech);

    // Ouverture du fichier en mode lecture
    filename = fopen("Compte.txt", "r");
    if (filename == NULL) {
        printf("Le fichier Compte.txt ne peut pas être ouvert.\n");
        exit(1);
    }

    while (fscanf(filename, "%ld %99s %99s %99s %d %f\n", &pin, lastName, firstName, numberPhone, &age, &solde) == 6) {
        if (pinRech == pin) {
            trouve = 1;
            break;
        }
    }

    if (trouve) {
        printf("Le solde du compte avec le code PIN %ld est de: %.2f\n", pin, solde);
    } else {
        printf("Aucun compte trouve avec ce code PIN.\n");
    }

    fclose(filename);
}

void editPin() {
    FILE *inputFile, *tempFile;
    char lastName[100], firstName[100], numberPhone[20];
    float solde;
    int age;
    long pinFromFile, oldPin, newPin;
    int rech = 0;

    // Ouverture du fichier d'entrée en mode lecture
    inputFile = fopen("Compte.txt", "r");
    if (inputFile == NULL) {
        printf("Erreur! Impossible de se connecter aux donnees du comptes.\n");
        exit(1);
    }

    // Ouverture d'un fichier temporaire en mode écriture
    tempFile = fopen("tempCompte.txt", "w");
    if (tempFile == NULL) {
        printf("Impossible de créer le fichier temporaire\n");
        exit(1);
    }

    printf("[+] Entrez votre ancien code pin: ");
    scanf("%ld", &oldPin);

    printf("[+] Entrez votre nouveau code pin: ");
    scanf("%ld", &newPin);

    // Lecture des données du fichier et écriture dans le fichier temporaire
    while (fscanf(inputFile, "%ld %99s %99s %99s %d %f\n", &pinFromFile, lastName, firstName, numberPhone, &age, &solde) == 6) {
        if (pinFromFile == oldPin) {
            // Si le code pin correspond, écrire le nouveau code pin
            fprintf(tempFile, "%ld\n%s\n%s\n%s\n%d\n%.2f\n\n\n", newPin, lastName, firstName, numberPhone, age, solde);
            rech = 1;
        } else {
            // Sinon, écrire l'ancien code pin
            fprintf(tempFile, "%ld\n%s\n%s\n%s\n%d\n%.2f\n\n\n", pinFromFile, lastName, firstName, numberPhone, age, solde);
        }
    }

    fclose(inputFile);
    fclose(tempFile);

    // Si le code pin a été trouvé et modifié, mettre à jour le fichier principal
    if (rech) {
        remove("Compte.txt");
        rename("tempCompte.txt", "Compte.txt");
        printf("Code pin modifié avec succès.\n");
    } else {
        printf("Aucun compte trouvé avec l'ancien code pin.\n");
        remove("tempCompte.txt"); // Supprimer le fichier temporaire si aucun changement n'a été fait
    }
}


// Creer votre compte MOMO et beneficier de 50.000€ (génial n'est-ce pas ?)
void createCompte() {
    long pinRech = 0;
    int rech = 0;
    FILE *filename;
    char lastName[100], firstName[100], numberPhone[20];
    float solde= 50000.00;
    int age;
    long pin;

    // Ouverture du fichier en mode lecture/écriture
    filename = fopen("Compte.txt", "r+");
    if (filename == NULL) {
        printf("============= CREATION DU COMPTE =============\nchargement...\n");
        for(int i= 3; i > 0; i--)
            printf("%d...\n", i);
        // Création d'un nouveau fichier si aucun compte n'existe
        filename = fopen("Compte.txt", "at+");
        if (filename == NULL) {
            printf("Impossible de créer le fichier Compte.txt\n");
            exit(1);
        }
    }

    printf("[+] Entrer un code pin: ");
    scanf("%ld", &pinRech);

    while (fscanf(filename, "%ld %99s %99s %99s %d %f\n", &pin, lastName, firstName, numberPhone, &age, &solde) == 6) {
        if (pinRech == pin) {
            rech = 1;
            break;
        }
    }

    if (rech == 1) {
        printf("Un compte existe deja avec ce code pin !!\n");
    } else {
        printf("[+] Saisissez votre nom: ");
        scanf("%99s", lastName);
        printf("[+] Saisissez votre prenom: ");
        scanf("%99s", firstName);
        printf("[+] Saisissez votre numero de téléphone: ");
        scanf("%99s", numberPhone);
        printf("[+] Entrez l'age: ");
        scanf("%d", &age);

        fseek(filename, 0, SEEK_END);
        fprintf(filename, "%ld\n%s\n%s\n%s\n%d\n%.2f\n\n\n", pinRech, lastName, firstName, numberPhone, age, solde);
    }

    fclose(filename);
}

#endif // FUNCION_MOMO
