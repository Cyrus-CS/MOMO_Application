#include<stdio.h>
#include<stdlib.h>
#include "Momo.h"

int menu();

int main(int argc, char *argv[]) {
    switch(menu()) {
        case 1:
            sendMoney();
            break;
        case 2:
            receiveMoney();
            break;
        case 3:
            ConsulteSolde();
            break;
        case 4:
            editPin();
            break;
        case 5:
            createCompte();
            break;
        case 6:
            printf("------- FIN DU PROGRAMME -----------\n\n");
            exit(1);
            break;
        default:
            printf("Aucun de vos choix ne correspond! Desole");
    }
    return 0;
}

int menu() {
    int choix = 0;
    do {
        //si vous utilisez "system("cls"); alors il serai judicieux d'importer windows.h comme ceci: #include<windows.h>
        //system("cls"); cette instruction permet  de nettoyer l'ecran sur WINDOWS !
        //Sur LINUX , utilisez "clear" au lieu de "cls"

        //SI LE PROGRAMME SE PLANTE METTEZ LE(system("cls") EN COMMENTAIRE
        printf("------------ ENVOI ET RECEPTION D'ARGENT ------------\n\n");
        printf("1- Envoi d'argent\n");
        printf("2- Reception d'argent\n");
        printf("3- Consultez votre solde\n");
        printf("4- Modifier le code PIN\n");
        printf("5- Creer un compte\n");
        printf("6-QUITTER!\n\n");

        printf("Veuillez entrer votre choix: ");
        scanf("%d", &choix);
    } while(choix < 1 || choix > 6);

    return choix;
}
